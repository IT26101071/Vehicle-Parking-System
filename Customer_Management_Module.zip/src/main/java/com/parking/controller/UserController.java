package com.parking.controller;

import com.parking.dto.CreateUserRequest;
import com.parking.model.User;
import com.parking.service.UserService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.sql.SQLException;
import java.util.List;

@RestController
@RequestMapping("/api/users")
public class UserController {
    private final UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;
    }

    @PostMapping
    public ResponseEntity<User> createUser(@RequestBody CreateUserRequest request) throws SQLException {
        User created = userService.createUser(toUser(request));
        return ResponseEntity.status(HttpStatus.CREATED).body(created);
    }

    @GetMapping
    public ResponseEntity<List<User>> getAllUsers() throws SQLException {
        return ResponseEntity.ok(userService.getAllUsers());
    }

    @GetMapping("/{userId}")
    public ResponseEntity<User> getUserById(@PathVariable Long userId) throws SQLException {
        return ResponseEntity.ok(userService.getUserById(userId));
    }

    @PutMapping("/{userId}")
    public ResponseEntity<Void> updateUser(@PathVariable Long userId,
                                           @RequestBody CreateUserRequest request) throws SQLException {
        return userService.updateUser(userId, toUser(request))
                ? ResponseEntity.noContent().build() : ResponseEntity.notFound().build();
    }

    @DeleteMapping("/{userId}")
    public ResponseEntity<Void> deleteUser(@PathVariable Long userId) throws SQLException {
        return userService.deleteUser(userId)
                ? ResponseEntity.noContent().build() : ResponseEntity.notFound().build();
    }

    private User toUser(CreateUserRequest request) {
        return new User(null, request.getFullName(), request.getEmail(),
                request.getPhoneNumber(), request.getAddress());
    }
}
