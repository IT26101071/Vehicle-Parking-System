package com.parking.service;

import com.parking.model.User;
import java.sql.SQLException;
import java.util.List;

public interface UserService {
    User createUser(User user) throws SQLException;
    List<User> getAllUsers() throws SQLException;
    User getUserById(Long userId) throws SQLException;
    boolean updateUser(Long userId, User user) throws SQLException;
    boolean deleteUser(Long userId) throws SQLException;
}
