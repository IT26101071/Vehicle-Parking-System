package com.parking.service.impl;

import com.parking.model.User;
import com.parking.repository.custom.UserRepository;
import com.parking.service.UserService;
import org.springframework.stereotype.Service;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import java.util.NoSuchElementException;

@Service
public class UserServiceImpl implements UserService {
    private final UserRepository userRepository;
    private final DataSource dataSource;

    public UserServiceImpl(UserRepository userRepository, DataSource dataSource) {
        this.userRepository = userRepository;
        this.dataSource = dataSource;
    }

    @Override
    public User createUser(User user) throws SQLException {
        validateUser(user);
        user.setFullName(user.getFullName().trim());
        user.setEmail(user.getEmail().trim().toLowerCase(java.util.Locale.ROOT));
        try (Connection connection = dataSource.getConnection()) {
            if (!userRepository.create(user, connection)) {
                throw new IllegalStateException("User creation failed");
            }
            return user;
        }
    }

    @Override
    public List<User> getAllUsers() throws SQLException {
        try (Connection connection = dataSource.getConnection()) {
            return userRepository.findAll(connection);
        }
    }

    @Override
    public User getUserById(Long userId) throws SQLException {
        validateId(userId);
        try (Connection connection = dataSource.getConnection()) {
            return userRepository.findById(userId, connection)
                    .orElseThrow(() -> new NoSuchElementException("User not found: " + userId));
        }
    }

    @Override
    public boolean updateUser(Long userId, User user) throws SQLException {
        validateId(userId);
        validateUser(user);
        user.setFullName(user.getFullName().trim());
        user.setEmail(user.getEmail().trim().toLowerCase(java.util.Locale.ROOT));
        try (Connection connection = dataSource.getConnection()) {
            if (userRepository.findById(userId, connection).isEmpty()) {
                return false;
            }
            return userRepository.update(userId, user, connection);
        }
    }

    @Override
    public boolean deleteUser(Long userId) throws SQLException {
        validateId(userId);
        try (Connection connection = dataSource.getConnection()) {
            return userRepository.deleteById(userId, connection);
        }
    }

    private void validateId(Long userId) {
        if (userId == null || userId <= 0) {
            throw new IllegalArgumentException("User ID must be a positive number");
        }
    }

    private void validateUser(User user) {
        if (user == null) throw new IllegalArgumentException("User details are required");
        if (user.getFullName() == null || user.getFullName().isBlank())
            throw new IllegalArgumentException("Full name is required");
        if (user.getEmail() == null || !user.getEmail().trim().matches("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$"))
            throw new IllegalArgumentException("A valid email is required");
        if (user.getPhoneNumber() == null || !user.getPhoneNumber().matches("[0-9+ -]{7,20}"))
            throw new IllegalArgumentException("A valid phone number is required");
        if (user.getAddress() == null || user.getAddress().isBlank())
            throw new IllegalArgumentException("Address is required");
    }
}
