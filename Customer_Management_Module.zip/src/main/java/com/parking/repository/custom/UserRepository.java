package com.parking.repository.custom;

import com.parking.model.User;
import com.parking.repository.CrudRepository;

// Inheritance: reuses the common CRUD method definitions.
public interface UserRepository extends CrudRepository<User, Long> {
}
